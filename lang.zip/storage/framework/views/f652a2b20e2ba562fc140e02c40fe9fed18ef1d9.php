

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Items bought by The user</h1>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->item_quantity != 0): ?>
            <div class="column">
                <div class="row">
                    <div class="col-md-3"> <a href="#"><img src=<?php echo e(asset($item->picture_link)); ?> alt="Logo"></a>
                    </div>
                </div>
            </div>
            <span class="h5">Name:<?php echo e($item->item_name); ?></span>
            <span class="h4">Quantity:<?php echo e($item->item_quantity); ?></span>
            <br>
            <button> <a href="<?php echo e(route('cart.destroy', ['id' => $item->id])); ?>" class="btn btn-danger">Remove Item -1</a>


                <button> <a href="<?php echo e(route('cart.update', ['id' => $item->id])); ?> " class="btn btn-primary">Add Item +1</a>
                </button>
        <?php endif; ?>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <footer>
        <div class="footer-div">
            <div class="container">
                <div class="row footer">
                    <div class="col-sm-12 col-md-6">
                        <ul class="footer-li">
                            <li class="services"><b>Services</b></li>
                            <li>E-Commerce Store</li>
                            <li>Products</li>
                        </ul>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <ul class="footer-li">
                            <li class="about"><b>About</b></li>
                            <li>Company</li>
                            <li>Team</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <h6>Copyright © 2022 Boxhill & Co., LLC.</h6>
        </div>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Semester 6 books\Web Technologies\Laravel projects\lab3\resources\views/pages/cart.blade.php ENDPATH**/ ?>